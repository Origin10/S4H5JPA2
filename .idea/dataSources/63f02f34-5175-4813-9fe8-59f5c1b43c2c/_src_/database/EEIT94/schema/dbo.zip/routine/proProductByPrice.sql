
CREATE PROCEDURE proProductByPrice
	@param_price float AS
BEGIN
	SET NOCOUNT ON;
	SELECT * FROM product WHERE price>@param_price
END
GO
